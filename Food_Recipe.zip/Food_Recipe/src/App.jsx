import React from 'react'
import Meal from './Meal'

const App = () => {
  return (
    <div>
      <Meal />
    </div>
  )
}

export default App